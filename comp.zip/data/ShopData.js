import img1 from "@/public/ShoesGallery/1.png";
import img2 from "@/public/ShoesGallery/2.png";
import img3 from "@/public/ShoesGallery/3.png";
import img4 from "@/public/ShoesGallery/4.png";
import img5 from "@/public/ShoesGallery/5.png";
import img6 from "@/public/ShoesGallery/6.png";
import img7 from "@/public/ShoesGallery/7.png";
import img8 from "@/public/ShoesGallery/8.png";
import img9 from "@/public/ShoesGallery/9.png";
import img10 from "@/public/ShoesGallery/10.png";
import img11 from "@/public/ShoesGallery/11.png";
import img12 from "@/public/ShoesGallery/12.png";
import img13 from "@/public/ShoesGallery/13.png";
import img14 from "@/public/ShoesGallery/14.png";
import img15 from "@/public/ShoesGallery/15.png";
import img16 from "@/public/ShoesGallery/16.png";
import img17 from "@/public/ShoesGallery/17.png";
import img18 from "@/public/ShoesGallery/18.png";
const ShopData = [
  { id: 1, sale: "New", img: img1, name: "Nike Air Max" },
  { id: 2, sale: "New", img: img2, name: "Adidas Boost" },
  { id: 3, sale: "New", img: img3, name: "Puma Runner" },
  { id: 4, sale: "New", img: img4, name: "Reebok Classic" },
  { id: 5, img: img5, name: "Nike Zoom" },
  { id: 6, img: img6, name: "Asics Gel" },
  { id: 7, img: img7, name: "Fila Sport" },
  { id: 8, img: img8, name: "New Balance" },
  { id: 9, img: img9, name: "Jordan Low" },
  { id: 10, img: img10, name: "Nike Flex" },
  { id: 11, img: img11, name: "Puma X" },
  { id: 12, img: img12, name: "Adidas Pro" },
  { id: 13, img: img13, name: "Nike Court" },
  { id: 14, img: img4, name: "Reebok Speed" },
  { id: 15, img: img15, name: "Asics Run" },
  { id: 16, img: img18, name: "Fila Max" },
  { id: 17, img: img5, name: "Jordan Fly" },
  { id: 18, img: img11, name: "Nike Street" },
  { id: 19, img: img16, name: "Adidas Edge" },
  { id: 20, img: img10, name: "Puma Evo" },
  { id: 21, img: img1, name: "Nike Air Max" },
  { id: 22, img: img2, name: "Adidas Boost" },
  { id: 23, img: img3, name: "Puma Runner" },
  { id: 24, img: img4, name: "Reebok Classic" },
];

export default ShopData;
