import INDEX from "./(with-sidebar)/home/page.jsx";
export default function HomePage() {
  return (
    <div className="">
      <INDEX />
    </div>
  );
}
